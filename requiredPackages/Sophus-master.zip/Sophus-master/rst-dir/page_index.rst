Sophus -  Lie groups for 2d/3d Geometry
=======================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   GitHub Page <https://github.com/strasdat/Sophus>
   pysophus