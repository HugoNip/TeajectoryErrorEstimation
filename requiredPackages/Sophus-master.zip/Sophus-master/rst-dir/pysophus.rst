Python API
==========

.. automodule:: sophus.matrix
   :members:

.. automodule:: sophus.complex
   :members:

.. automodule:: sophus.quaternion
   :members:

.. automodule:: sophus.so2
   :members:

.. automodule:: sophus.so3
   :members:

.. automodule:: sophus.se2
   :members:

.. automodule:: sophus.se3
   :members: